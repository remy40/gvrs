<?php

/*


  This file is same as ~/freichat/server/admin_files/home/index.php

 */
header('Location: admin.php');
?>