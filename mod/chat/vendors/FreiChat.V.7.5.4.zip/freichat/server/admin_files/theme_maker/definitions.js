    var freidefines = {     
        
    GEN :{
        
        url:'<?php echo $thm->url; ?>',
        curr_theme:'<?php echo $_SESSION[$thm->uid."curr_theme"]; ?>',
        RDIR:'<?php echo RDIR; ?>'
    },    
        
    file_exts    :'<?php echo $thm->valid_exts; ?>',
    freichatheadimg:'<?php echo $freichatheadimg; ?>',
    freiuserbrandimg:'<?php echo $frei_user_brandimg; ?>',
    rtlimg_enabled:'<?php echo $rtlimg_enabled; ?>',
    rtlimg_disabled:'<?php echo $rtlimg_disabled; ?>',
    gchatimg:'<?php echo $gchatimg; ?>',
    mailimg: '<?php echo $mailimg; ?>',
    saveimg: '<?php echo $saveimg; ?>',
    smileyimg: '<?php echo $smileyimg; ?>',
    arrowimg: '<?php echo $arrowimg; ?>',
    newtopimg: '<?php echo $newtopimg; ?>',
    btopimg:'<?php echo $btopimg; ?>',
    bmidimg:'<?php echo $bmidimg; ?>',
    notransimg: '<?php echo $translatedisabledimg; ?>',
    translateimg:'<?php echo $translateimg; ?>',
    uploadimg:'<?php echo $uploadimg; ?>',
    deleteimg:'<?php echo $deleteimg; ?>',
    minimg:'<?php echo $minimg; ?>',
    maximg:'<?php echo $maximg; ?>',
    closeimg:'<?php echo $closeimg; ?>',
    logoutimg:'<?php echo $logoutimg; ?>',
    onlineimg:'<?php echo $onlineimg; ?>',
    busyimg:'<?php echo $busyimg; ?>',
    invisibleimg:'<?php echo $invisibleimg; ?>',
    restoreimg:'<?php echo $restoreimg; ?>',
    offlineimg:'<?php echo $offlineimg; ?>',
    offline:'<?php echo $offline; ?>',
    optimg:'<?php echo $optimg; ?>',
    toolimg:'<?php echo $toolimg; ?>',
    frei_optionsimg:'<?php echo $frei_optionsimg; ?>',
    frei_tools_optionsimg:'<?php echo $frei_tools_optionsimg; ?>',
    freismileyimg:'<?php echo $freismileyimg; ?>',
    
    
    //chatroom
    chatroomimg:'<?php echo $chatroomimg; ?>',
    chatroom_head:'<?php echo $chatroom_head; ?>',
    chatroom_leftpanel:'<?php echo $chatroom_leftpanel; ?>',
    chatroom_selected:'<?php echo $chatroom_selected; ?>',
    
    thememaker:true
    }      
          
          
          
$jn = $;          