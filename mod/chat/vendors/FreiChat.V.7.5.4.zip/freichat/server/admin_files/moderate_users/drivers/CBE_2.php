<?php

require 'Joomla.php';

class CBE_2 extends Joomla {
    
    public function __construct() {
        
    }
} 
