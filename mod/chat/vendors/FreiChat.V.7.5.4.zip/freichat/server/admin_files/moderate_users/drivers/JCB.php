<?php

require 'Joomla.php';

class JCB extends Joomla {
} 
