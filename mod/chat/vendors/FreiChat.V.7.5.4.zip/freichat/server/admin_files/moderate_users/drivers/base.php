<?php

class Moderation {

    public $db;
    public $db_prefix;
    public $host;
    public $client_db_name;
    public $username;
    public $password;
    public $row_username;
    public $row_userid;
    public $usertable;
    
}