<?php

require 'Joomla.php';

class JSocial extends Joomla {
    
    public function __construct() {
        
    }
} 
